# LeParrain — trois conditions à vérifier

Exemple éditorial original proposé à Antoine pour son brief de vidéos TikTok/Reels. 20 secondes, 1080×1920, français, sans son. Aucun résultat d’audience garanti, aucune campagne client revendiquée. Ne pas présenter comme une publication déjà diffusée.

## Sources et droits

Sujet inspiré de la FAQ publique https://leparrain.com/ consultée le 11 septembre 2026 : vérifier les conditions de chaque programme (éligibilité, action, délai). Aucun montant de bonus ni délai universel. Texte et diagrammes originaux. Polices Space Grotesk et Inter provenant de google/fonts, licences OFL incluses dans public/fonts.

## Livrables

- index.html et compositions/frames : source animée HyperFrames.
- renders/video.mp4 : export final après contrôle.
- snapshots/contact-sheet.jpg : aperçu des séquences.

Le rendu reste à effectuer tant que VALIDATION.md ne confirme pas les contrôles.
